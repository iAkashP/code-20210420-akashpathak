from setuptools import setup,find_packages

setup(
    name='BMI Calculator',
    version='0.1',
    description='Python BMI Calculator Coding Challenge',
    author='Akash Pathak',
    author_email='iamakashpathak@gmail.com',
    packages=['BMI_Calculator'],
    install_requires=['Pandas','Numpy'],

)